-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 07, 2019 at 05:21 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vote`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate_register`
--

CREATE TABLE IF NOT EXISTS `candidate_register` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(222) NOT NULL,
  `secondname` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(222) NOT NULL,
  `gender` varchar(222) NOT NULL,
  `dept` varchar(222) NOT NULL,
  `discription` varchar(300) NOT NULL,
  `phone_no` varchar(222) NOT NULL,
  `percentage_of_mark` varchar(222) NOT NULL,
  `percentage_of_attendance` varchar(222) NOT NULL,
  `photo` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `reenter_password` varchar(222) NOT NULL,
  `status` varchar(100) NOT NULL,
  `vote_event` varchar(100) NOT NULL,
  `astatus` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `candidate_register`
--

INSERT INTO `candidate_register` (`id`, `firstname`, `secondname`, `email`, `dob`, `address`, `gender`, `dept`, `discription`, `phone_no`, `percentage_of_mark`, `percentage_of_attendance`, `photo`, `password`, `reenter_password`, `status`, `vote_event`, `astatus`) VALUES
(45, 'zakir', 's', 'zakir@gmail.com', '2019-03-06', '#78,Zakir ali Mzn,Kannur', 'male', 'IIIrd BSC MATHS', 'i zakir, persuing  no.072615, i would like to work as a candidate ', '9724566746', '67', '78', 'upload/modern-male-fashion-with-glasses_4460x4460.jpg', 'zakir', 'zakir', '', '', 'Accepted'),
(44, 'anju', 'k', 'anju@gmail.com', '2019-03-06', '#787,#rd floor, Swestf,Kannur', 'Female', 'IInd BA ENGLISH', 'i Anju, persuing  no.0475, i would like to work as a candidate ', '9744378945', '78', '89', 'upload/beautiful-beautiful-girl-eyes-724258.jpg', 'anju', 'anju', '', '', 'Accepted'),
(43, 'vinod', 'd', 'vinod@gmail.com', '2019-11-06', '#57, Kannur-670001', 'male', 'IInd BCA', 'I Would like to work as a Candidate', '9458458731', '90', '78', 'upload/professional-man-smiling_4460x4460.jpg', 'a', 'a', '', '', 'Accepted'),
(42, 'john', 'k', 'john@gmail.com', '2019-03-16', '#98, swerty, kannur', 'male', 'IInd BA ENGLISH', 'i john , persuing  no.023, i would like to work as a candidate ', '9348348546', '90', '78', 'upload/j.jpg', '123', '123', '', '', 'Accepted'),
(47, 'aswathi', 'n', 'ashwathi@gmail.com', '2019-03-07', '#909, 4th main,rgtjrgf, kannur', 'Female', 'IIIrd BBA', 'i aswathi, persuing  no.9769, i would like to work as a candidate ', '9013578921', '90', '90', 'upload/smiling-businesswoman-in-office_4460x4460.jpg', '123', '123', 'VOTED', 'Precident', 'Accepted'),
(48, 'suraj', 's', 'suraj@gmail.com', '2019-03-07', 'suraj villa, kannur', 'male', 'IIIrd BCA', 'i suraj, persuing  no.0233, i would like to work as a candidate ', '9274823678', '90', '78', 'upload/young-man-portrait_4460x4460.jpg', '123', '123', '', '', 'Accepted'),
(54, 'k', 'k', 'k@gmail.com', '2019-03-07', 'kkkk', 'Female', 'Ist BCA', 'kk', '0909898098', '90', '09', 'upload/aa.jpg', '123', '123', '', '', 'Accepted'),
(53, 'arya', 'cv', 'arya@gmail.com', '2019-03-27', 'ramyas,kannur', 'Female', 'IInd BA ENGLISH', 'I arya, persuing usn 91, i would like to work as candidate', '917827586', '89', '90', 'upload/Capture.PNG', '123', '123', '', '', 'Accepted'),
(50, 'alen', 'r', 'alen@gmail.com', '2019-03-07', '#78,jsdhjs,kannur', 'male', 'IIIrd BSC MATHS', 'i alen, persuing  no.98, i would like to work as a candidate ', '7456782341', '78', '70', 'upload/aa.jpg', '123', '123', '', '', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `message` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `message`) VALUES
(1, '', '', '', ''),
(2, 'a', 'a', 'a', 'a'),
(3, 's', 's', 's', 's'),
(4, 'qq', 'a', '43', 'ews'),
(5, '', '', '', ''),
(6, '', '', '', ''),
(7, '', '', '', ''),
(8, 'a', 'arya@gmail.com', '6666666666666', 'jhghjgjh'),
(9, 'a', 'arya@gmail.com', '95204493043', 'aaaaaaaaaaaaaaaaaaaaaaaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `election_event`
--

CREATE TABLE IF NOT EXISTS `election_event` (
  `election_id` int(33) NOT NULL AUTO_INCREMENT,
  `election_title` varchar(222) NOT NULL,
  `election_date` varchar(100) NOT NULL,
  `no_of_candidate` int(222) NOT NULL,
  `election_end_date` date NOT NULL,
  PRIMARY KEY (`election_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `election_event`
--

INSERT INTO `election_event` (`election_id`, `election_title`, `election_date`, `no_of_candidate`, `election_end_date`) VALUES
(9, 'arts join secretory election', '2019-02-22', 4, '2019-02-25'),
(10, 'Precident', '2019-02-27', 4, '2019-07-06');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `subject` varchar(222) NOT NULL,
  `message` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'diya', 'd@gmail.com', 'vote', 'not responding'),
(2, 'niyaÂ r', 'niya@gmail.com', 'asd', 'bnjmk,l.;/\r\n'),
(3, 'Â ', '', '', ''),
(4, 'DevikaÂ r', 'devu@gmail.com', ' login', 'login failed '),
(5, 'Â o o', 'o@gmail.com', 'a', 'a'),
(6, 'amyÂ k', 'amy@gmail.com', 'gjjjjjjgi', 'sehu'),
(7, 'Â o o', 'o@gmail.com', 'gjjjjjjgi', 'hiiiiiiiiiiiiiiiiiiiiiiiiiiiiii'),
(8, 'nivyaraj', 'nivyaraj@gmail.com', 'arts and join sectory', 'good work'),
(9, 'AthiraÂ p', 'athu@gmail.com', 'errors occured', ''),
(10, 'AthiraÂ p', 'athu@gmail.com', 'errors', 'errors occured'),
(11, 'amyÂ k', 'amy@gmail.com', '', 's'),
(12, 's', 'a@gmail.com', 'ss', 's'),
(13, 'akur', 'aku@gmail.com', 'vote', ''),
(14, 'raibaÂ rebin', 'raiba@gmail.com', 'errrr', 'fghjkl'),
(15, 'anuÂ rag', 'anu@gmail.com', 'vote', 'simple and powerfull');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `usertype` varchar(222) NOT NULL,
  `status` varchar(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=300 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `usertype`, `status`) VALUES
(291, 'akshay@gmail.com', '123', 'candidate', '0'),
(290, 'zakir@gmail.com', 'zakir', 'candidate', '1'),
(289, 'anju@gmail.com', 'anju', 'candidate', '1'),
(157, 'admin', 'admin', 'admin', '1'),
(288, 'vinod@gmail.com', 'a', 'candidate', '1'),
(287, 'yaad@gmail.com', 'o', 'student', '1'),
(286, 'john@gmail.com', '123', 'candidate', '1'),
(285, 'jaya@gmail.com', 'jaya', 'student', '1'),
(292, 'ashwathi@gmail.com', '123', 'candidate', '1'),
(293, 'suraj@gmail.com', '123', 'candidate', '1'),
(295, 'alen@gmail.com', '123', 'candidate', '1'),
(299, 'k@gmail.com', '123', 'candidate', '1'),
(297, 'jaya@gmail.com', '123', 'candidate', '0'),
(298, 'arya@gmail.com', '123', 'candidate', '1');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `date` varchar(33) NOT NULL,
  `discription` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `date`, `discription`) VALUES
(14, '14.February.2019', 'election end');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `event` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(33) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `discription` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `event`, `name`, `email`, `photo`, `discription`) VALUES
(38, 'arts join secretory election', 'zakir ', 'zakir@gmail.com', 'upload/modern-male-fashion-with-glasses_4460x4460.jpg', 'Winner Of Arts Join Secretory election is mr.Zakir');

-- --------------------------------------------------------

--
-- Table structure for table `user_register`
--

CREATE TABLE IF NOT EXISTS `user_register` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(222) NOT NULL,
  `secondname` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(222) NOT NULL,
  `gender` varchar(222) NOT NULL,
  `dept` varchar(222) NOT NULL,
  `phone_no` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `reenter_password` varchar(222) NOT NULL,
  `status` varchar(100) NOT NULL,
  `vote_event` varchar(100) NOT NULL,
  `astatus` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=243 ;

--
-- Dumping data for table `user_register`
--

INSERT INTO `user_register` (`id`, `firstname`, `secondname`, `email`, `dob`, `address`, `gender`, `dept`, `phone_no`, `password`, `reenter_password`, `status`, `vote_event`, `astatus`) VALUES
(242, 'yaad', 'v', 'yaad@gmail.com', '2019-03-06', 'jhjlhhjhhjhjkhk', 'Female', 'Ist BCA', '0000000000', 'o', 'o', '', '', 'Accepted'),
(241, 'jaya', 'n', 'jaya@gmail.com', '2001-07-19', '#78,3th main ,kannur', 'Female', 'IIIrd BCOM', '9347376837', 'jaya', 'jaya', '', '', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `vote_candidate`
--

CREATE TABLE IF NOT EXISTS `vote_candidate` (
  `id` int(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `event` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `votecount` varchar(100) NOT NULL,
  `result` varchar(100) NOT NULL,
  `reason` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `vote_candidate`
--

INSERT INTO `vote_candidate` (`id`, `name`, `email`, `photo`, `event`, `description`, `votecount`, `result`, `reason`) VALUES
(21, 'zakir ', 'zakir@gmail.com', 'upload/modern-male-fashion-with-glasses_4460x4460.jpg', 'arts join secretory election', 'I would like to work as arts joint secretory,<br> tht ill ensure that change the campus city', '8', 'Winner Of Arts Join Secretory election is mr.Zakir', '0'),
(20, 'anju ', 'anju@gmail.com', 'upload/beautiful-beautiful-girl-eyes-724258.jpg', 'arts join secretory election', 'I would like to work as arts joint secretory,<br> tht ill ensure that change the campus city', '6', 'Winner Of Arts Join Secretory election is mr.Zakir', '0'),
(18, 'john ', 'john@gmail.com', 'upload/j.jpg', 'arts join secretory election', 'I would like to work as arts joint secretory,<br> tht ill ensure that change the campus city\r\n', '4', 'Winner Of Arts Join Secretory election is mr.Zakir', '0'),
(19, 'vinod ', 'vinod@gmail.com', 'upload/professional-man-smiling_4460x4460.jpg', 'arts join secretory election', 'I would like to work as arts joint secretory,<br> tht ill ensure that change the campus city\r\n', '5', 'Winner Of Arts Join Secretory election is mr.Zakir', '0'),
(30, 'arya', 'arya@gmail.com', 'upload/Capture.PNG', 'Precident', 'I would like to work as precident,<br> tht ill ensure that change the campus ', '0', '', '0'),
(29, 'j', 'jaya@gmail.com', 'upload/index-1_img-2.jpg', '0', '0', '0', '', '0'),
(24, 'aswathi', 'ashwathi@gmail.com', 'upload/smiling-businesswoman-in-office_4460x4460.jpg', 'Precident', 'I would like to work as precident,<br> tht ill ensure that change the campus ', '0', '', '0'),
(25, 'suraj', 'suraj@gmail.com', 'upload/young-man-portrait_4460x4460.jpg', 'Precident', 'I would like to work as Precident,<br> tht ill ensure that change the campus ', '1', '', '0'),
(27, 'alen', 'alen@gmail.com', 'upload/aa.jpg', 'Precident', 'I would like to work as Precident,<br> tht ill ensure that change the campus ', '0', '', '0'),
(28, 'aani', 'aani@gmail.com', 'upload/bb.jpeg', '0', '0', '0', '', '0'),
(31, 'k', 'k@gmail.com', 'upload/aa.jpg', 'arts join secretory election', 'hrhgfdhlgd', '0', '', '0');
