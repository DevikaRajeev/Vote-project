<?php
session_start();
$candidate=$_SESSION['username'];
if(isset($_SESSION['username']))
{
//echo $_SESSION['username'];
}
else
{
echo "<script>alert('you must login first!!..');document.location.href='login.php';</script>";
//header("Location:dcrs/Login.php");
echo"this document is protected";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no"/>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/grid.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/camera.css"/>
    <link rel="stylesheet" href="css/owl.carousel.css"/>
    <script src="js/jquery.js"></script>
    <script src="js/jquery-migrate-1.2.1.js"></script>
    <script src="js/jquery.equalheights.js"></script>
    <!--[if (gt IE 9)|!(IE)]><!-->
    <script src="js/jquery.mobile.customized.min.js"></script>
    <!--<![endif]-->
    <script src="js/camera.js"></script>
    <script src="js/owl.carousel.js"></script>
    <!--[if lt IE 9]>
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
            <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0"
                 height="42" width="820"
                 alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."/>
        </a>
    </div>
    <script src="js/html5shiv.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
    <![endif]-->
	<link href="voting.css" type="text/css" rel="stylesheet" />
<script src="jscript/gen_validatorv4.js" type="text/javascript"></script>

</head>
<body>
<div class="page">
<!--========================================================
                          HEADER
=========================================================-->
<header id="header">
    <div id="stuck_container">
        <div class="container">
            <div class="row">
                <div class="grid_12">
                    <div class="brand put-left">
                        <h1>
                            <a href="index.html">
                                <img src="images/campus/download (4).jpeg" height="90" width="90" alt="Logo"/>
                            </a>
                        </h1>
                    </div>
                    <nav class="nav put-right">
                        <ul class="sf-menu">
                            
            <li class="current" style="font-family:Georgia, 'Times New Roman', Times, serif"><a href="candidate_home.php">Home</a></li>
                            
            <li style="font-family:Georgia, 'Times New Roman', Times, serif"> 
              <a href="candidate_electionevent.php" ><b>Election Event</b></a></li>
						    
            <li style="font-family:Georgia, 'Times New Roman', Times, serif"> 
              <a href="candidate_vote.php">Vote</a> </li>
							
            <li style="font-family:Georgia, 'Times New Roman', Times, serif"> 
              <a href="candidate_result.php">Result</a> </li>
                            
            <li style="font-family:Georgia, 'Times New Roman', Times, serif"><a href="candidate_feedback.php">Feedback</a></li>
                            
            <li style="font-family:Georgia, 'Times New Roman', Times, serif"><a href="candidate_notification.php">Notification</a></li>
							 
            <li style="font-family:Georgia, 'Times New Roman', Times, serif"><a href="logout.php">Logout</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>
<div id="cover"> 
  <div id="content"> 
    <h4>Hellow,&nbsp;<?php echo $candidate ;?><br />
    </h4>
    <br/>
    <h3>Make a vote.</h3>
    <div id="login"> 
      <table width="100%">
	
<form action="" name="vote" method="post" id="myform">
  <?php
 $connect=mysql_connect("localhost","root","");
	          $db=mysql_select_db("vote");
			  $query="select * from vote_candidate ";
			  
			  $result=mysql_query($query,$connect);
			  //echo"$query";
			  while($res=mysql_fetch_array($result))
			  {
			  
	
			  $id=$res['id'];
			  $name=$res['name'];
			 // $secondname=$res['secondname'];
			  $email=$res['email'];
			  $photo=$res['photo'];
			  $event=$res['event'];
			  //$etype=$res['event'];
			  //$name="$firstname"."$secondname";
			  
?>
<tr>
<td align="left"><img src="<?php echo $photo; ?>" width="200px" height="100%"><br><br></td>
<td align="left">
<input type="radio" name="can" value="<?php echo $name;?>" /><?php echo $name;?>
</td>
</tr>
<?php
		
		}
		?>
		
<tr><td align="center"><input type="submit" value="MAKE A VOTE" name="submit"/></td>
</tr>
</form>
<?php
$connect=mysql_connect("localhost","root","");
	          $db=mysql_select_db("vote");
if(isset($_POST['submit']))
{
$sql = "SELECT * FROM candidate_register WHERE email='$candidate' AND status='VOTED'";
$result = mysql_query($sql);

			if (mysql_num_rows($result)==1){
	    //Login User already voted:
	   // echo $cand1;
        $msg="<center><h4><font color='#FF0000'>You have already been voted, No need to vote again</h4></center></font>";
			echo $msg ;
	        }
					
			else{
			
			 $sql = 'UPDATE vote_candidate SET votecount = votecount + 1 WHERE name = "'.$_POST['can'].'" ';
         
            $sql2 = "UPDATE candidate_register SET status='VOTED' WHERE email='$candidate' ";
               

            $result = mysql_query($sql);
            $result2 = mysql_query($sql2);

	if(!$result && !$result2){
	die("Error on mysql query".mysql_error());
	}
	else{
	$msg1="<center><h4><font color='#FF0000'>Congratulation, you have made your vote.</h4></center></font>";
	echo"$msg1";
	}
			}
	
}	
?>

        <script type="text/javascript">
 var frmvalidator = new Validator("myform"); 
 frmvalidator.addValidation("cand1","req","Please select president candidate to vote for.");
 frmvalidator.addValidation("vice1","req","Please select vice candidate to vote for.");  
</script>
      </table>
    </div>
  </div>
</div>
